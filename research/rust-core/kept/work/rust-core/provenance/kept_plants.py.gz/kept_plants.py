"""Scratch: do kept_evidence.py's checks bite? Each plant is made in a copy of the kept folder, in scratch; the
repository's kept folder is never touched. Run from the Orlog root: python -B kept_plants.py SCR"""
import gzip
import importlib.util
import io
import os
import shutil
import sys
from contextlib import redirect_stdout

SCR = sys.argv[1]
spec = importlib.util.spec_from_file_location("ke", os.path.join("research", "rust-core", "kept_evidence.py"))
ke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ke)
REAL = ke.KEPT
results = []


def run(kept):
    ke.KEPT, ke.MANIFEST = kept, os.path.join(kept, "MANIFEST.txt")
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            ok = ke.check()
    except Exception as e:
        return False, "raised %s" % type(e).__name__
    return ok, buf.getvalue().strip().split("\n")[-1]


def plant(name, fn):
    d = os.path.join(SCR, "keptplant", name)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(REAL, d)
    fn(d)
    ok, last = run(d)
    results.append(not ok)
    print("%-6s %s: %s" % ("CAUGHT" if not ok else "MISSED", name, last[:110]))


ok, last = run(REAL)
results.append(ok)
print("%-6s control, the kept folder as it is: %s" % ("PASS" if ok else "FAIL", last[:110]))
rows = [ln.split(" | ") for ln in open(os.path.join(REAL, "MANIFEST.txt"), encoding="utf-8")
        if ln.strip() and not ln.startswith("#")]
first = rows[0]


def flip_kept(d):          # one byte of a kept file changed: its own sha256 and, decompressed, the source's differ
    p = os.path.join(d, first[3][len("kept/"):])
    b = bytearray(open(p, "rb").read())
    b[len(b) // 2] ^= 1
    open(p, "wb").write(bytes(b))


def recompress(d):         # the kept file replaced by other bytes that decompress to something else
    p = os.path.join(d, first[3][len("kept/"):])
    open(p, "wb").write(gzip.compress(b"not the evidence", 9, mtime=0))


def manifest_sha(d):       # the manifest's sha256 of the source changed
    p = os.path.join(d, "MANIFEST.txt")
    t = open(p, encoding="utf-8").read().replace(first[2], first[2][:-1] + ("0" if first[2][-1] != "0" else "1"), 1)
    open(p, "w", encoding="utf-8", newline="\n").write(t)


def manifest_len(d):       # the manifest's length changed
    p = os.path.join(d, "MANIFEST.txt")
    t = open(p, encoding="utf-8").read().replace(" | %s | " % first[1], " | %d | " % (int(first[1]) + 1), 1)
    open(p, "w", encoding="utf-8", newline="\n").write(t)


def gone(d):               # a kept file removed
    os.remove(os.path.join(d, first[3][len("kept/"):]))


for name, fn in (("a byte of a kept file flipped", flip_kept), ("a kept file replaced", recompress),
                 ("the manifest's sha256 changed", manifest_sha), ("the manifest's length changed", manifest_len),
                 ("a kept file removed", gone)):
    plant(name, fn)
print("KEPT PLANTS: %d of %d as stated" % (sum(results), len(results)))
