"""Reconstruct gen_r6_reference.py as it was at sha256 48d88b21... by undoing, newest first, the Edit calls this
session's transcript records on it, from the file as it now stands; accept only an exact sha256 match. Read-only on
the repository; writes OUT only. python regen_gen48.py TRANSCRIPT CURRENT OUT"""
import hashlib
import json
import sys

transcript, current, out = sys.argv[1:4]
WANT = "48d88b2167c2c676ebcbda70804753b4b72bbaa90729e2e05348a95ba66abc87"
edits, failed = [], set()
with open(transcript, "rb") as f:
    for raw in f:
        try:
            rec = json.loads(raw)
        except Exception:
            continue
        c = (rec.get("message") or {}).get("content")
        if not isinstance(c, list):
            continue
        for p in c:
            if isinstance(p, dict) and p.get("type") == "tool_use" and p.get("name") in ("Edit", "Write", "MultiEdit"):
                inp = p.get("input") or {}
                if str(inp.get("file_path", "")).replace("\\", "/").endswith("rust-core/gen_r6_reference.py"):
                    edits.append((p["name"], inp, p.get("id")))
            if isinstance(p, dict) and p.get("type") == "tool_result" and p.get("is_error"):
                failed.add(p.get("tool_use_id"))
print("failed calls skipped:", sum(1 for e in edits if e[2] in failed))
seen = set()
unique = []
for n, i, t in edits:              # the transcript holds some calls twice, under one id
    if t not in seen and t not in failed:
        seen.add(t)
        unique.append((n, i))
edits = unique
print("edit calls on the generator in the transcript:", len(edits), [e[0] for e in edits].count("Write"), "writes")
text = open(current, encoding="utf-8").read()
sha = lambda t: hashlib.sha256(t.encode("utf-8")).hexdigest()
print("current", sha(text)[:16])
undone = 0
for name, inp in reversed(edits):
    if sha(text) == WANT:
        break
    if name != "Edit":
        print("a", name, "call stands between: stop")
        break
    old, new = inp["old_string"], inp["new_string"]
    if inp.get("replace_all"):
        print("a replace_all edit: stop")
        break
    if text.count(new) != 1:
        print("an edit's new text is not found once (%d): stop" % text.count(new))
        break
    text = text.replace(new, old)
    undone += 1
print("undone", undone, "->", sha(text)[:16], "MATCH" if sha(text) == WANT else "no match")
if sha(text) == WANT:
    with open(out, "x", encoding="utf-8", newline="\n") as f:
        f.write(text)
    print("written", out)
