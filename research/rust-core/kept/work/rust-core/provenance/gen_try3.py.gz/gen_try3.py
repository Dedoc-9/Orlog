"""Scratch: the amended generator (R6 remake ruling) on 20 mutants, its records in scratch, with plants. Run from the
Orlog root: python -B gen_try3.py SCR"""
import json
import os
import shutil
import subprocess
import sys

SCR = sys.argv[1]
src = open(os.path.join("research", "rust-core", "gen_r6_reference.py"), encoding="utf-8").read()
base = os.path.join(SCR, "gentry3")
shutil.rmtree(base, ignore_errors=True)
os.makedirs(base)
ENV = dict(os.environ, PYTHONHASHSEED="0", PYTHONUTF8="1")
results = []


def make(name, extra=()):
    s = src.replace("HERE = os.path.dirname(os.path.abspath(__file__))",
                    "HERE = %r" % os.path.abspath(os.path.join("research", "rust-core")))
    s = s.replace('RECORDS = os.path.join(ROOT, "work", "rust-core", "attempts")',
                  "RECORDS = %r" % os.path.join(base, name, "att"))
    s = s.replace("    mutants = gen_r6_mutants.mutants(mpath)\n", "    mutants = gen_r6_mutants.mutants(mpath)[:20]\n")
    for a, b in extra:
        assert s.count(a) == 1, a
        s = s.replace(a, b)
    os.makedirs(os.path.join(base, name))
    p = os.path.join(base, name, "gen.py")
    open(p, "w", encoding="utf-8", newline="\n").write(s)
    return p


def go(p, *args):
    d = os.path.dirname(p)
    q = subprocess.run([sys.executable, "-B", p, "--out", os.path.join(d, "g1.txt"), os.path.join(d, "g2.txt"),
                        "--record", os.path.join(d, "record.txt")] + list(args), capture_output=True, env=ENV)
    out = q.stdout.decode("utf-8", "replace").strip().split("\n")
    return q.returncode, out, q.stderr.decode("utf-8", "replace").strip()


def row(name, ok, detail):
    results.append(ok)
    print("%-4s %s: %s" % ("PASS" if ok else "FAIL", name, detail))


def att(name, ident):
    d = os.path.join(base, name, "att", ident)
    a = json.load(open(os.path.join(d, "attempt.json"), encoding="utf-8"))
    e = json.load(open(os.path.join(d, "end.json"), encoding="utf-8"))
    runs = [json.loads(x) for x in open(os.path.join(d, "runs.jsonl"), encoding="utf-8")]
    host = [json.loads(x) for x in open(os.path.join(d, "host.jsonl"), encoding="utf-8")] \
        if os.path.exists(os.path.join(d, "host.jsonl")) else []
    return a, e, runs, host


# 1. the two generations one after the other, equal, the record written
p = make("seq")
rc, out, err = go(p)
d = os.path.join(base, "seq")
a1, e1, r1, h1 = att("seq", "r6-reference-5-gen1-a1")
a2, e2, r2, h2 = att("seq", "r6-reference-5-gen2-a1")
row("both complete, equal, record written", rc == 0 and out[-1].startswith("GEN-R6-REF: the two generations are BYTE FOR BYTE EQUAL")
    and open(os.path.join(d, "record.txt"), "rb").read() == open(os.path.join(d, "g1.txt"), "rb").read(),
    "exit %d; %s" % (rc, out[-1][:110]))
last1 = max(r["end"] for r in r1)
first2 = min(r["start"] for r in r2)
row("generation 2 starts after generation 1 ends, by the runs' times", first2 >= last1,
    "gen 1 last end %.3f, gen 2 first start %.3f (%.3f s later)" % (last1, first2, first2 - last1))
row("every run has its start and end, start <= end", all("start" in r and "end" in r and r["start"] <= r["end"]
                                                          for r in r1 + r2), "%d runs" % len(r1 + r2))
row("the host's commit before, during, after", all(x["host_before"]["commit"] for x in (a1, a2))
    and all(x["host_after"]["commit"] and x["host_before"]["commit"] for x in (e1, e2)) and len(h1) > 5 and len(h2) > 5
    and all(h["commit"] and h["commit_limit"] for h in h1 + h2),
    "readings %d and %d; clock %s, resolution %s s" % (len(h1), len(h2), a1["clock"]["implementation"],
                                                       a1["clock"]["resolution_s"]))
row("the readings span the generation", h1[0]["t"] >= a1["host_before"]["t"] and h1[-1]["t"] <= e1["host_after"]["t"],
    "gen 1 readings %.1f to %.1f" % (h1[0]["t"], h1[-1]["t"]))
row("end records carry the file's sha256", e1["output_sha256"] == e2["output_sha256"]
    == __import__("hashlib").sha256(open(os.path.join(d, "g1.txt"), "rb").read()).hexdigest(), e1["output_sha256"][:16])
row("header says one after the other", b"made one after the other" in open(os.path.join(d, "g1.txt"), "rb").read(), "")

# 2. run again: refused, the record never written over
rc, out, err = go(p)
row("again: refused", rc != 0 and "exists; a record is never written over" in (err + " ".join(out)), (err or out[-1])[:100])

# 3. unequal generations: no record (plant: generation 2's fourth row changed)
p = make("unequal", [("    data = (\"\\n\".join(head + rows) + \"\\n\").encode(\"ascii\")\n",
                      "    if gen == 2:\n        rows[3] = rows[3] + ' planted'\n"
                      "    data = (\"\\n\".join(head + rows) + \"\\n\").encode(\"ascii\")\n")])
rc, out, err = go(p)
d = os.path.join(base, "unequal")
row("unequal: fails verification, no record", rc == 1 and "NOT EQUAL (1 lines differ: 00004)" in out[-1]
    and not os.path.exists(os.path.join(d, "record.txt")), out[-1][:120])

# 4. --only 2 before generation 1 completed: refused
p = make("only2")
rc, out, err = go(p, "--only", "2")
row("--only 2 first: refused", rc != 0 and "starts only once generation 1 has completed" in err, err[:100])

# 5. generation 1 interrupted (a planted start failure): generation 2 not started, no record
p = make("int1", [("    try:\n        p = subprocess.Popen(",
                   "    try:\n        if num == '00005' and '-gen1-' in attempt.folder:\n"
                   "            raise OSError(1450, 'planted')\n        p = subprocess.Popen(")])
rc, out, err = go(p)
d = os.path.join(base, "int1")
a, e, runs, host = att("int1", "r6-reference-5-gen1-a1")
row("gen 1 interrupted: gen 2 not started, no record", rc == 1 and e["disposition"] == "INTERRUPTED"
    and e["cause"] == "HARNESS-FAULT" and not os.path.exists(os.path.join(base, "int1", "att", "r6-reference-5-gen2-a1"))
    and not os.path.exists(os.path.join(d, "record.txt")) and any("NOT STARTED" in x for x in out),
    " | ".join(x[:60] for x in out))

# 6. --only 1, then a changed generation 1 file, then --only 2: refused, no record
p = make("tamper")
rc, out, err = go(p, "--only", "1")
d = os.path.join(base, "tamper")
row("--only 1 alone: completes, nothing compared", rc == 1 and "generation 2 has not completed" in out[-1], out[-1][:100])
with open(os.path.join(d, "g1.txt"), "ab") as f:
    f.write(b"x")
rc, out, err = go(p, "--only", "2")
row("a changed generation 1 file: no record", rc == 1 and "is not the one" in out[-1]
    and not os.path.exists(os.path.join(d, "record.txt")), out[-1][:100])

print("GEN-TRY3: %d of %d" % (sum(results), len(results)))
