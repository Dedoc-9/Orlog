"""Mutant 09729 through the reference runner, N copies at once, each with its peak commit (PeakPagefileUsage). Scratch,
read-only of the repository. Run from the Orlog root: python m09729.py N OUTDIR"""
import ctypes
import ctypes.wintypes as W
import os
import subprocess
import sys
import tempfile
import time

N, OUT = int(sys.argv[1]), sys.argv[2]
os.makedirs(OUT, exist_ok=True)
hexs = None
for line in open("research/rust-core/r6-mutants.txt", encoding="utf-8"):
    if line.startswith("09729 "):
        hexs = line.split(" hex ")[1].strip()
law = os.path.join(OUT, "09729.law")
open(law, "wb").write(bytes.fromhex(hexs))


class PMC(ctypes.Structure):
    _fields_ = [("cb", W.DWORD), ("PageFaultCount", W.DWORD), ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t), ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t), ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t), ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t)]


psapi = ctypes.WinDLL("psapi")
env = dict(os.environ, PYTHONHASHSEED="0", PYTHONUTF8="1")
ps = []
for i in range(N):
    d = tempfile.mkdtemp(dir=OUT)
    t0 = time.perf_counter()
    p = subprocess.Popen([sys.executable, "-B", "research/rust-core/ref_run.py", "law", "1000000", "0" * 64,
                          os.path.abspath(law)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
                         cwd=os.getcwd(), creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
    ps.append((p, t0))
for i, (p, t0) in enumerate(ps):
    out, err = p.communicate(timeout=120)
    wall = time.perf_counter() - t0
    m = PMC()
    m.cb = ctypes.sizeof(m)
    psapi.GetProcessMemoryInfo(int(p._handle), ctypes.byref(m), m.cb)
    exc = [l for l in err.decode("utf-8", "replace").splitlines() if l.startswith("REFERENCE-EXCEPTION")]
    print("copy %d of %d: exit %s wall %.1f s peak commit %.2f GiB peak working set %.2f GiB %s"
          % (i + 1, N, p.returncode, wall, m.PeakPagefileUsage / 2**30, m.PeakWorkingSetSize / 2**30, exc))
