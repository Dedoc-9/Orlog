"""RUST-CORE-0: does ref_run_paths.py catch the runner changes the re-reads showed passing it? (REREAD-6's M7,
REREAD-7's X3; SHEET.md Amendment 7.)

Run from the repository's root: PYTHONHASHSEED=0 PYTHONUTF8=1 python -B research/rust-core/ref_run_variants.py

Each variant is a copy of research/rust-core/ref_run.py with one change, made in a temporary folder, never in the
repository. A copy of ref_run_paths.py is pointed at it and run; the variant is caught when that check fails (exit 1,
"FAILED"). The control, the runner unchanged, must pass. The variants are REREAD-6's five and REREAD-7 reader 2's eleven
(V1-V11), as they read against the runner's code now. A variant the check does not catch is said, with what does
catch it, if anything. Evidence about the check, not about the reference; outside the core author's reading set (D1)."""
import concurrent.futures
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
ROOTLINE = "ROOT = os.path.dirname(os.path.dirname(HERE))"
RUN_OLD = "    try:\n        it.run()\n    except interp.HostStop as e:\n"
VARIANTS = [   # (name, [(text, replacement)], what catches it if this check does not)
    ("control: the runner unchanged", [], None),
    ("REREAD-6: the ENV line removed", [('print("ENV python', '(lambda *a, **k: None)("ENV python')], None),
    ("REREAD-6: the recursion limit raised", [("        from orlog import interp\n",
                                               "        from orlog import interp\n        sys.setrecursionlimit(100000)\n")],
     None),
    ("REREAD-6: format_check imported", [("        from orlog import interp\n",
                                          "        from orlog import interp\n        sys.path.insert(0, HERE)\n"
                                          "        import format_check\n")], None),
    ("REREAD-6: BUDGET read from os.environ", [
        ('    return mode, None if budget_s == "none" else int(budget_s), textseal, raw, files',
         '    budget_s = os.environ.get("REF_BUDGET", budget_s)\n'
         '    return mode, None if budget_s == "none" else int(budget_s), textseal, raw, files')], None),
    ("V1: law mode ignores BUDGET", [("it = interp.Interp(prog, an, law_seal, text_seal, trace=True, budget=budget)",
                                      "it = interp.Interp(prog, an, law_seal, text_seal, trace=True, "
                                      "budget=None if mode == \"law\" else budget)")], None),
    ("V2: the law seal from the bytes less their last LF", [("law_seal, text_seal = sha(raw), textseal",
                                                            "law_seal, text_seal = sha(raw[:-1]), textseal")], None),
    ("V3: decoder1's message dropped", [('return "DECODER-REFUSED %s" % ascii(str(e))',
                                         'return "DECODER-REFUSED \'x\'"')], None),
    ("V4: a KeyError from decode taken as a refusal", [("except decoder1.DecodeError as e:",
                                                       "except (decoder1.DecodeError, KeyError) as e:")], None),
    ("V5: a stop reports one operation more", [('return "RUN STOPPED ops %d trace %s" % (e.ops, ',
                                                'return "RUN STOPPED ops %d trace %s" % (e.ops + 1, ')], None),
    ("V6: classify, two different results RESULT", [('if a[0] == "result" and a == b:',
                                                      'if a[0] == "result" and b[0] == "result":')], None),
    ("V7: classify, two different refusals REFERENCE-REFUSED", [('if a[0] == "refused" and a == b:',
                                                                 'if a[0] == "refused" and b[0] == "refused":')], None),
    ("V8: the recursion limit raised by getattr", [("        from orlog import interp\n",
                                                    "        from orlog import interp\n"
                                                    "        getattr(sys, 'setrecursion' + 'limit')(100000)\n")], None),
    ("V9: BUDGET read through `from os import environ`", [
        (ROOTLINE, "from os import environ as _e\n" + ROOTLINE),
        ('    return mode, None if budget_s == "none" else int(budget_s), textseal, raw, files',
         "    budget_s = _e.get('REF_BUDGET', budget_s)\n"
         '    return mode, None if budget_s == "none" else int(budget_s), textseal, raw, files')], None),
    ("V10: P keeps the text-seal line in law mode only", [
        ('p = "\\n".join(ln for ln in lines if not ln.startswith(("backend ", "text-seal ")))',
         'p = "\\n".join(ln for ln in lines if not ln.startswith(("backend ",) if mode == "law" else '
         '("backend ", "text-seal ")))')], None),
    ("V11: an IndexError in law mode's run taken as a refusal", [
        (RUN_OLD, "    try:\n        it.run()\n"
                  "    except (interp.HostStop if mode == 'text' else (interp.HostStop, IndexError)) as e:\n"
                  "        if not isinstance(e, interp.HostStop):\n"
                  "            return \"DECODER-REFUSED %s\" % ascii(str(e))\n")],
     "no case of this check: no input of it makes the interpreter raise IndexError. The record's rows would change "
     "(REREAD-7's reader 2), so the hash closure of a record made by such a runner fails"),
]


def one(k, name, edits, runner_src, paths_src, work):
    d = os.path.join(work, "v%02d" % k)
    os.makedirs(d)
    r = runner_src.replace(ROOTLINE, "ROOT = %r" % ROOT)
    for old, new in edits:
        if r.count(old) != 1 and old != ROOTLINE:
            return name, "NOT MADE (its text is not found once)", None
        r = r.replace(old, new) if old != ROOTLINE else r.replace("ROOT = %r" % ROOT, new.replace(
            ROOTLINE, "ROOT = %r" % ROOT), 1)
    with open(os.path.join(d, "ref_run.py"), "w", encoding="utf-8", newline="\n") as f:
        f.write(r)
    p = (paths_src.replace('RUNNER = os.path.join(HERE, "ref_run.py")', "RUNNER = %r" % os.path.join(d, "ref_run.py"))
         .replace("sys.path.insert(0, HERE)\nimport ref_run", "sys.path.insert(0, %r)\nimport ref_run" % d)
         .replace("ROOT = os.path.dirname(os.path.dirname(HERE))", "ROOT = %r" % ROOT))
    with open(os.path.join(d, "paths.py"), "w", encoding="utf-8", newline="\n") as f:
        f.write(p)
    q = subprocess.run([sys.executable, "-B", os.path.join(d, "paths.py")], capture_output=True,
                       env=dict(os.environ, PYTHONHASHSEED="0", PYTHONUTF8="1"))
    last = [ln for ln in q.stdout.decode("utf-8", "replace").replace("\r\n", "\n").split("\n") if ln]
    return name, q.returncode, last[-1] if last else ""


def main():
    with open(os.path.join(HERE, "ref_run.py"), encoding="utf-8") as f:
        runner_src = f.read()
    with open(os.path.join(HERE, "ref_run_paths.py"), encoding="utf-8") as f:
        paths_src = f.read()
    work = tempfile.mkdtemp(prefix="refrunvariants-")
    try:
        with concurrent.futures.ThreadPoolExecutor(3) as pool:
            results = list(pool.map(lambda kv: one(kv[0], kv[1][0], kv[1][1], runner_src, paths_src, work),
                                    enumerate(VARIANTS)))
    finally:
        shutil.rmtree(work, ignore_errors=True)
    print("THE RUNNER CHANGES THE RE-READS SHOWED, AGAINST ref_run_paths.py (research/rust-core/ref_run_variants.py)")
    bad = caught = 0
    for (name, edits, other), (_, status, last) in zip(VARIANTS, results):
        if not edits:
            ok = status == 0 and "HELD" in last
            print("   %-58s %s  [%s]" % (name, last, "as it must" if ok else "NOT AS IT MUST"))
        elif status == 1 and "FAILED" in last:
            ok, caught = True, caught + 1
            print("   %-58s caught: %s" % (name, last))
        else:
            ok = other is not None
            print("   %-58s NOT CAUGHT (%s): %s" % (name, last or status, other or "and nothing else names it"))
        bad += not ok
    n = len(VARIANTS) - 1
    print("REF-RUN VARIANTS %s: %d of %d changes caught by the check; the control passes; %d not caught, each said" % (
        "HELD" if bad == 0 else "FAILED", caught, n, n - caught))
    sys.exit(0 if bad == 0 else 1)


if __name__ == "__main__":
    main()
