"""RUST-CORE-0: every way the reference runner ends, through classify (SHEET.md Amendments 5 to 7; REREAD-5's L3 and
L5, REREAD-6's M7, REREAD-7's X3, X4, X13 and Y14, and the owner's D5).

Run from the repository's root: PYTHONHASHSEED=0 PYTHONUTF8=1 python -B research/rust-core/ref_run_paths.py

Each case runs research/rust-core/ref_run.py twice, each a fresh `python -B` process whose working directory is a fresh
empty folder, its input in another. The two raw runs go to `ref_run.classify`, and the class it gives, or what it
raises instead (a runner fault, an anomaly, an interruption), must be the one stated here; so must each run's exit
status, stderr's last line, and, where this check computes it itself, stdout's last line.

- **The outcome lines** of a completed text, a completed law, a law stopped by its budget and a law decoder1 refuses
  are computed here, in this process, by the interpreter and decoder1 themselves, and the runner's must equal them
  (REREAD-7's X3: a runner that ignored the budget in law mode, took the law seal from other bytes, dropped decoder1's
  message or miscounted a stop passed the earlier check).
- **The paths the real modules never take** (an exit, an interrupt or a plant inside decode; a failing platform query;
  an `orlog` or decoder1 import that raises something other than `ImportError`) are reached through a stand-in put in
  place before the runner starts, so the real modules are not changed. A wrong pin and a `__pycache__` folder are
  reached through copies of the runner made here.
- **The run conditions** (REREAD-6's M7, REREAD-7's X3 and X13): every run that reaches the reference prints the ENV
  line first, with a fresh interpreter's default recursion limit, `format_check not-imported`, and every `orlog`
  module by the sha256 of its file as it stands; and, before its outcome, the after-run line alike.
- **Some cases of classify** are checked on runs made up here: timeouts, crash types, two different results and two
  different refusals (REREAD-7's X3), an exit 3 without its line (an anomaly), an exit status the runner never gives
  with and without `KeyboardInterrupt` (his D5).
- **The runner's source** is read by its syntax tree (REREAD-7's X3): no name or attribute `environ`, `getenv`,
  `putenv` or `setrecursionlimit`, imported or not; no `getattr` on `os` or `sys`; no import of `format_check`.

It writes nothing in the repository, and prints nothing that varies from run to run. It is evidence that the runner
ends as its docstring says, not that the reference is right, and it is outside the core author's reading set (D1)."""
import ast
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
RUNNER = os.path.join(HERE, "ref_run.py")
sys.path.insert(0, HERE)
import ref_run                  # noqa: E402

S = "§"
H = b"orlog-law 0\n(decimals fixed)\n"
STAND_IN = '''import importlib.abc, platform, runpy, sys, types
mode = sys.argv[1]
if mode == "envinterrupt":
    def boom(*a, **k):
        raise KeyboardInterrupt
    platform.platform = boom
elif mode == "envoserror":
    def boom(*a, **k):
        raise OSError("a platform query that fails")
    platform.platform = boom
elif mode == "orlogvalue":
    class Broken(types.ModuleType):
        def __getattr__(self, name):
            raise ValueError("an orlog that fails as it is read")
    sys.modules["orlog"] = Broken("orlog")
elif mode == "decoderraise":
    class Finder(importlib.abc.MetaPathFinder):
        def find_spec(self, name, path=None, target=None):
            if name == "decoder1":
                raise ValueError("a decoder1 that fails as it is found")
            return None
    sys.meta_path.insert(0, Finder())
else:
    m = types.ModuleType("decoder1")
    class DecodeError(Exception):
        pass
    m.DecodeError = DecodeError
    m.PLANT = "a plant" if mode == "plant" else None
    def decode(raw):
        if mode == "exit":
            raise SystemExit(0)
        if mode == "interrupt":
            raise KeyboardInterrupt
        if mode == "refuse":
            raise DecodeError("a refusal")
        if mode == "keyerror":
            raise KeyError("a crash that is not a refusal")
        raise ValueError("a stand-in that decodes nothing")
    m.decode = decode
    sys.modules["decoder1"] = None if mode == "noimport" else m
sys.argv = [sys.argv[2]] + sys.argv[3:]
runpy.run_path(sys.argv[0], run_name="__main__")
'''
COPIES = ("wrongpin", "pycache")


def run(args, work, stand_in=None, files=False, runner=RUNNER):
    """One fresh run: (exit status, stdout bytes, stderr bytes), and the names it left in its folder."""
    folder = tempfile.mkdtemp(dir=work)
    env = dict(os.environ, PYTHONHASHSEED="0", PYTHONUTF8="1")
    head = [sys.executable, "-B"] + ([stand_in[0], stand_in[1], runner] if stand_in else [runner])
    p = subprocess.run(head + args + (["--files"] if files else []), capture_output=True, cwd=folder, env=env)
    left = sorted(os.listdir(folder))
    shutil.rmtree(folder)
    return (p.returncode, p.stdout, p.stderr), left


def verdict(r1, r2):
    try:
        return ref_run.classify(r1, r2)
    except ref_run.RunnerFault:
        return "RUNNER-FAULT"
    except ref_run.Anomaly:
        return "ANOMALY"
    except ref_run.Interrupted:
        return "INTERRUPTED"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def outcome(interp, prog, an, law_seal, text_seal, budget):
    """The outcome line, computed here by the interpreter itself, as the runner's docstring states it."""
    it = interp.Interp(prog, an, law_seal, text_seal, trace=True, budget=budget)
    try:
        it.run()
    except interp.HostStop as e:
        return "RUN STOPPED ops %d trace %s" % (e.ops, sha("\n".join(it.trace).encode("ascii")))
    rl = it.receipt("reference").decode("ascii").split("\n")
    pr = "\n".join(ln for ln in rl if not ln.startswith(("backend ", "text-seal ")))
    st = [ln for ln in rl if ln.startswith("status ")][0][len("status "):].split(" ")[0]
    ops = int([ln for ln in rl if ln.startswith("ops ")][0][len("ops "):])
    return "RUN %s ops %d p %s trace %s" % (st, ops, sha(pr.encode("ascii")), sha("\n".join(it.trace).encode("ascii")))


def lines_of(data):
    return [ln for ln in data.decode("ascii", "replace").replace("\r\n", "\n").split("\n") if ln]


def conditions_ok(line, tail):
    """A conditions line: the default recursion limit, format_check not loaded, and every orlog module listed by the
    sha256 of its file as it stands (and at least orlog.interp)."""
    if tail not in line or "; orlog " not in line:
        return False
    mods = dict(x.split("=", 1) for x in line.split("; orlog ", 1)[1].split(" ") if "=" in x)
    if "orlog.interp" not in mods:
        return False
    for name, digest in mods.items():
        parts = name.split(".")
        path = os.path.join(ROOT, "src", *parts) + ".py"
        if not os.path.isfile(path):
            path = os.path.join(ROOT, "src", *parts, "__init__.py")
        with open(path, "rb") as f:
            if sha(f.read()) != digest:
                return False
    return True


def source_rows(src):
    """REREAD-7's X3: the runner's source by its syntax tree, not by substrings."""
    tree = ast.parse(src)
    banned = {"environ", "getenv", "putenv", "setrecursionlimit"}
    names, getattrs, fc = set(), False, False
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            names.add(node.id)
        elif isinstance(node, ast.Attribute):
            names.add(node.attr)
        elif isinstance(node, ast.ImportFrom):
            names.update(a.name for a in node.names)
            fc = fc or (node.module or "").split(".")[0] == "format_check"
        elif isinstance(node, ast.Import):
            fc = fc or any(a.name.split(".")[0] == "format_check" for a in node.names)
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "getattr" and node.args
                and isinstance(node.args[0], ast.Name) and node.args[0].id in ("os", "sys")):
            getattrs = True
    return [("no name environ, getenv, putenv or setrecursionlimit", not names & banned),
            ("no getattr on os or sys", not getattrs),
            ("no import of format_check", not fc)]


def main():
    work = tempfile.mkdtemp(prefix="refrunpaths-")
    try:
        inputs = os.path.join(work, "inputs")
        os.mkdir(inputs)

        def put(name, data):
            path = os.path.join(inputs, name)
            with open(path, "wb") as f:
                f.write(data)
            return path

        sys.path.insert(0, os.path.join(ROOT, "src"))
        from orlog import interp
        from orlog.front import compile_bytes
        sys.path.insert(0, os.path.join(ROOT, "research", "law-sufficiency"))
        import decoder1
        say_text = ("%s1 Say 1.\n%s2 Say 2.\n" % (S, S)).encode("utf-8")
        c = compile_bytes(say_text)
        say = put("say.orl", say_text)
        say_law = put("say.law", c.law)
        bad = put("bad.orl", ("%s1 Say.\n" % S).encode("utf-8"))
        empty = put("empty.law", H)
        v1_bytes = b"orlog-law 1\n(decimals fixed)\n"
        v1 = put("v1.law", v1_bytes)
        high = put("high.law", b"orlog-law 0\n(decimals fixed)\n\xff\n")
        stand = put("stand_in.py", STAND_IN.encode("ascii"))
        missing = os.path.join(inputs, "missing.law")
        z = "0" * 64
        # the outcome lines, computed here (REREAD-7's X3)
        want_text = outcome(interp, c.prog, c.an, c.law_seal, c.text_seal, None)
        lp, la = decoder1.decode(c.law)
        want_law = outcome(interp, lp, la, sha(c.law), z, None)
        lp, la = decoder1.decode(c.law)
        want_stop = outcome(interp, lp, la, sha(c.law), z, 0)
        ep, ea = decoder1.decode(H)
        want_empty = outcome(interp, ep, ea, sha(H), z, None)
        try:
            decoder1.decode(v1_bytes)
            want_refused = "decoder1 accepted version 1"
        except decoder1.DecodeError as e:
            want_refused = "DECODER-REFUSED %s" % ascii(str(e))
        U = "REFERENCE-EXCEPTION builtins.UnicodeDecodeError"
        X = "REFERENCE-EXCEPTION builtins.SystemExit"
        F = "RUNNER-FAULT "
        cases = [   # (what, args, stand-in or copy, the class stated, exit status, stderr's last line, stdout's last)
            ("text: a text the front end accepts", ["text", "none", say], None, "RESULT", 0, "", want_text),
            ("text: the same under budget 0", ["text", "0", say], None, "RESULT", 0, "", None),
            ("text: a text the front end refuses", ["text", "none", bad], None, "RUNNER-FAULT", 3, F, None),
            ("law: the empty law", ["law", "none", z, empty], None, "RESULT", 0, "", want_empty),
            ("law: a law that completes", ["law", "none", z, say_law], None, "RESULT", 0, "", want_law),
            ("law: the same law stopped by budget 0", ["law", "0", z, say_law], None, "RESULT", 0, "", want_stop),
            ("law: decoder1 refuses (version 1)", ["law", "none", z, v1], None, "REFERENCE-REFUSED", 0, "",
             want_refused),
            ("law: decoder1 crashes (a byte above 0x7E)", ["law", "none", z, high], None, "NO-REFERENCE-RESULT", 1, U,
             None),
            ("usage: no arguments", [], None, "RUNNER-FAULT", 3, F, None),
            ("usage: budget 1e6", ["law", "1e6", z, empty], None, "RUNNER-FAULT", 3, F, None),
            ("usage: budget -1", ["law", "-1", z, empty], None, "RUNNER-FAULT", 3, F, None),
            ("usage: budget 05", ["law", "05", z, empty], None, "RUNNER-FAULT", 3, F, None),
            ("usage: budget +5", ["law", "+5", z, empty], None, "RUNNER-FAULT", 3, F, None),
            ("usage: a text seal in capitals", ["law", "none", "A" * 64, empty], None, "RUNNER-FAULT", 3, F, None),
            ("usage: an input that does not exist", ["law", "none", z, missing], None, "RUNNER-FAULT", 3, F, None),
            ("stand-in: decode calls sys.exit(0)", ["law", "none", z, empty], "exit", "NO-REFERENCE-RESULT", 1, X, None),
            ("stand-in: decode raises KeyError", ["law", "none", z, empty], "keyerror", "NO-REFERENCE-RESULT", 1,
             "REFERENCE-EXCEPTION builtins.KeyError", None),
            ("stand-in: decode is interrupted", ["law", "none", z, empty], "interrupt", "RUNNER-FAULT", 3, F, None),
            ("stand-in: decoder1 holds a plant", ["law", "none", z, empty], "plant", "RUNNER-FAULT", 3, F, None),
            ("stand-in: decode refuses", ["law", "none", z, empty], "refuse", "REFERENCE-REFUSED", 0, "",
             "DECODER-REFUSED 'a refusal'"),
            ("stand-in: decoder1 cannot be imported", ["law", "none", z, empty], "noimport", "RUNNER-FAULT", 3,
             F + "decoder1 cannot be imported", None),
            ("stand-in: decoder1's import raises ValueError", ["law", "none", z, empty], "decoderraise",
             "RUNNER-FAULT", 3, F + "decoder1 cannot be imported: ValueError", None),
            ("stand-in: orlog's import raises ValueError", ["law", "none", z, empty], "orlogvalue", "RUNNER-FAULT", 3,
             F + "the reference's modules cannot be imported: ValueError", None),
            ("stand-in: the ENV line's platform query fails", ["law", "none", z, empty], "envoserror", "RUNNER-FAULT",
             3, F + "before the reference began: OSError", None),
            ("stand-in: the ENV line is interrupted", ["law", "none", z, empty], "envinterrupt", "RUNNER-FAULT", 3,
             F + "interrupted", None),
            ("a runner whose decoder1 pin is wrong", ["law", "none", z, empty], "wrongpin", "RUNNER-FAULT", 3,
             F + "decoder1.py is not the file", None),
            ("a runner beside a __pycache__ folder", ["law", "none", z, empty], "pycache", "RUNNER-FAULT", 3,
             F + "a __pycache__ folder stands in", None),
        ]
        print("THE REFERENCE RUNNER'S WAYS OF ENDING, THROUGH classify (research/rust-core/ref_run_paths.py)")
        rows = []
        default = int(subprocess.run([sys.executable, "-B", "-c", "import sys; print(sys.getrecursionlimit())"],
                                     capture_output=True).stdout.decode().strip())
        tail = "recursion-limit %d format_check not-imported; " % default
        with open(RUNNER, encoding="utf-8") as f:
            runner_src = f.read()
        fixed_root = "ROOT = %r" % ROOT
        copies = {}
        wrong = os.path.join(work, "wrongpin_ref_run.py")
        with open(wrong, "w", encoding="utf-8", newline="\n") as f:
            f.write(runner_src.replace('DECODER1_SHA256 = "', 'DECODER1_SHA256 = "0' + "0" * 63 + '"  # was "', 1)
                    .replace("ROOT = os.path.dirname(os.path.dirname(HERE))", fixed_root))
        copies["wrongpin"] = wrong
        cache_home = os.path.join(work, "cache_home")
        os.makedirs(os.path.join(cache_home, "__pycache__"))
        cached = os.path.join(work, "pycache_ref_run.py")
        with open(cached, "w", encoding="utf-8", newline="\n") as f:
            f.write(runner_src.replace("ROOT = os.path.dirname(os.path.dirname(HERE))", fixed_root)
                    .replace("BYTECODE = [", "BYTECODE = [%r] + [" % cache_home, 1))
        copies["pycache"] = cached
        for what, args, mode, want, want_exit, want_err, want_out in cases:
            if mode in COPIES:
                (r1, l1), (r2, l2) = run(args, work, runner=copies[mode]), run(args, work, runner=copies[mode])
            else:
                si = (stand, mode) if mode else None
                (r1, l1), (r2, l2) = run(args, work, si), run(args, work, si)
            got = verdict(r1, r2)
            ends = all(r[0] == want_exit and (ref_run.last_line(r[2]).startswith(want_err) if want_err else
                                              ref_run.last_line(r[2]) == "") for r in (r1, r2))
            out_ok = want_out is None or all(ref_run.last_line(r[1]) == want_out for r in (r1, r2))
            cond_ok = True
            for r in (r1, r2):
                ls = lines_of(r[1])
                if r[0] in (0, 1) or (ls and ls[0].startswith("ENV ")):
                    cond_ok = cond_ok and bool(ls) and ls[0].startswith("ENV python ") and conditions_ok(ls[0], tail)
                if r[0] == 0:
                    cond_ok = (cond_ok and len(ls) >= 3 and ls[-2].startswith("CONDITIONS after-run ")
                               and conditions_ok(ls[-2], tail))
            ok = got == want and ends and out_ok and cond_ok and not l1 and not l2
            rows.append(ok)
            print("   %-48s exit %d | out %-26s | err %-44s | %-19s %s" % (
                what, r1[0], ref_run.last_line(r1[1])[:26], ref_run.last_line(r2[2])[:44], got,
                "as stated" if ok else "NOT AS STATED (stated %s; out %s, conditions %s; left %s %s)"
                % (want, out_ok, cond_ok, l1, l2)))
        # --files: what a completed and a stopped run leave in their folders
        for what, args, want in [("--files: a completed run", ["text", "none", say],
                                  ["reference.out", "reference.receipt", "reference.trace"]),
                                 ("--files: a stopped run", ["text", "0", say], ["reference.out", "reference.trace"])]:
            r, left = run(args, work, files=True)
            ok = left == want and r[0] == 0
            rows.append(ok)
            print("   %-48s leaves %-52s %s" % (what, " ".join(left), "as stated" if ok else "NOT AS STATED"))
        # classify on runs made up here
        res = (0, b"ENV x\r\nRUN COMPLETED ops 1 p a trace b\r\n", b"")
        res2 = (0, b"ENV x\nRUN COMPLETED ops 2 p c trace d\n", b"")
        ref1 = (0, b"ENV x\nDECODER-REFUSED 'one'\n", b"")
        ref2 = (0, b"ENV x\nDECODER-REFUSED 'two'\n", b"")
        ki = (3221225786, b"ENV x\n", b"Traceback (most recent call last):\nKeyboardInterrupt\n")
        made = [("two timeouts", "TIMEOUT", "TIMEOUT", "NO-REFERENCE-RESULT"),
                ("a timeout and a result", "TIMEOUT", res, "UNSTABLE"),
                ("a result, CR LF and LF", res, (0, b"ENV x\nRUN COMPLETED ops 1 p a trace b\n", b""), "RESULT"),
                ("two different results", res, res2, "UNSTABLE"),
                ("two different refusals", ref1, ref2, "UNSTABLE"),
                ("two crashes of different types", (1, b"", b"REFERENCE-EXCEPTION builtins.KeyError\n"),
                 (1, b"", b"REFERENCE-EXCEPTION builtins.ValueError\n"), "UNSTABLE"),
                ("two crashes, one exit status each", (1, b"", b"REFERENCE-EXCEPTION builtins.KeyError\n"),
                 (2, b"", b"REFERENCE-EXCEPTION builtins.KeyError\n"), "UNSTABLE"),
                ("a runner fault's line", (3, b"", b"RUNNER-FAULT a reason\n"), res, "RUNNER-FAULT"),
                ("an exit 3 without its line", (3, b"", b""), res, "ANOMALY"),
                ("an unknown status with KeyboardInterrupt", ki, res, "INTERRUPTED"),
                ("an unknown status without it, twice", (3221226505, b"", b""), (3221226505, b"", b""),
                 "NO-REFERENCE-RESULT")]
        for what, a, b, want in made:
            got = verdict(a, b)
            rows.append(got == want)
            print("   %-48s %-19s %s" % ("made up: " + what, got, "as stated" if got == want else "NOT AS STATED"))
        for what, ok in source_rows(runner_src):
            rows.append(ok)
            print("   %-48s %s" % ("source: " + what, "as stated" if ok else "NOT AS STATED"))
        bad_count = rows.count(False)
        print("REF-RUN PATHS %s: %d of %d as stated" % ("HELD" if bad_count == 0 else "FAILED", len(rows) - bad_count,
                                                        len(rows)))
        sys.exit(0 if bad_count == 0 else 1)
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    main()
