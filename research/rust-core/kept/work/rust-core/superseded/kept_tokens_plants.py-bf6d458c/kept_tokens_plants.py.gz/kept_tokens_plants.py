"""RUST-CORE-0 phase 0: do kept_tokens.py's guarantees hold? His ruling (the ruling sheet, 2026-10-31, section II):
"Plants must cover every spelling, partial matches, multiple occurrences, and incorrect restoration inputs." And: "No
use of option (c) until those tests pass."

  python -B research/rust-core/kept_tokens_plants.py SCRATCH [REAL SOURCES... --prefix NAME=VALUE... --forbid TEXT...]

It works in SCRATCH only, never in the repository's kept folder. On made-up files (an account called `someone`, its
short form `SOMEON~1`, in five spellings) it plants every case below and requires the stated outcome. Given real
sources and their prefixes, it also keeps each in SCRATCH, restores it, and requires the original's sha256, and plants a
missing and a wrong prefix for every token each holds. The account and its prefixes are given on the command line and
written nowhere."""
import gzip
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kept_tokens as kt  # noqa: E402

BS = chr(92)
ESC = BS + BS
SPELLINGS = {                                   # the made-up account's five spellings, as bytes
    "HOME_ESC": ("C:" + ESC + "Users" + ESC + "someone").encode(),
    "HOME": ("C:" + BS + "Users" + BS + "someone").encode(),
    "HOME_FWD": b"C:/Users/someone",
    "HOME83_ESC": ("C:" + ESC + "Users" + ESC + "SOMEON~1").encode(),
    "HOME83": ("C:" + BS + "Users" + BS + "SOMEON~1").encode(),
}
FORBID = ["someone", "SOMEON~1"]
results = []


def row(name, ok, detail=""):
    results.append(ok)
    print("%-6s %s%s" % ("PASS" if ok else "FAIL", name, (": " + detail) if detail else ""))


def refused(fn):
    try:
        fn()
        return False, "not refused"
    except kt.Refused as e:
        return True, str(e)[:90]


def fixture():
    """Every spelling, three times each, adjacent to itself and to the others, at the start and at the end, inside longer
    paths, and beside near misses that are not the prefix (a shorter name, a missing separator)."""
    near = [b"C:" + BS.encode() + b"Users" + BS.encode() + b"someon", b"C:Users/someon", b"Users" + ESC.encode() + b"x"]
    parts = [SPELLINGS["HOME_ESC"]]             # at the start
    for name, v in SPELLINGS.items():
        parts += [b" ", v, v, b"|", v + ESC.encode() + b"Desktop" + ESC.encode() + b"Orlog", b" "]
    parts += near + [b"\n{\"path\": \"" + SPELLINGS["HOME_ESC"] + ESC.encode() + b"AppData\"}\n", SPELLINGS["HOME83"]]
    return b"".join(parts)


def main(argv):
    scr = argv[0]
    real = [a for i, a in enumerate(argv[1:], 1) if not a.startswith("--") and not argv[i - 1].startswith("--")]
    flags = argv[1:]
    real_prefixes = kt.parse_prefixes([flags[i + 1] for i in range(len(flags) - 1) if flags[i] == "--prefix"])
    real_forbid = [flags[i + 1] for i in range(len(flags) - 1) if flags[i] == "--forbid"]
    base = os.path.join(scr, "kept-tokens-plants")
    shutil.rmtree(base, ignore_errors=True)
    os.makedirs(base)
    src = os.path.join(base, "fixture.txt")
    data = fixture()
    open(src, "wb").write(data)
    kd = os.path.join(base, "kept")
    prefixes = {n: v for n, v in SPELLINGS.items()}

    # 1. every spelling, multiple occurrences, partial matches: kept, and restored byte for byte
    kt.make([src], prefixes, FORBID, kd)
    (rel, length, digest, kept, kept_digest, counts), = kt.rows(os.path.join(kd, "TOKENED.txt"))
    row("every spelling tokened, each several times", all(counts[n] >= 3 for n in SPELLINGS),
        ", ".join("%s=%d" % kv for kv in sorted(counts.items())))
    packed = open(os.path.join(kd, kept[len("kept/"):]), "rb").read()
    tokened = gzip.decompress(packed)
    row("no forbidden text left in what is kept", not any(f.lower().encode() in tokened.lower() for f in FORBID))
    row("the near misses kept as they were", all(m in tokened for m in (b"someon", b"C:Users/someon")))
    back = kt.restore(kept, None, prefixes, kd)
    row("restored byte for byte, the original's sha256", back == data and kt.sha(back) == digest)

    # 2-6. incorrect restoration inputs, each refused
    for name in SPELLINGS:
        ok, why = refused(lambda: kt.restore(kept, None, {k: v for k, v in prefixes.items() if k != name}, kd))
        row("missing prefix %s refused" % name, ok, why)
        ok, why = refused(lambda: kt.restore(kept, None, dict(prefixes, **{name: prefixes[name] + b"x"}), kd))
        row("wrong prefix %s refused" % name, ok, why)
    ok, why = refused(lambda: kt.parse_prefixes(["HOME=a", "HOME=b"]))
    row("a prefix given twice (ambiguous) refused", ok, why)
    ok, why = refused(lambda: kt.parse_prefixes(["HOME=a", "HOME=a"]))
    row("a prefix given twice with one value refused too", ok, why)
    ok, why = refused(lambda: kt.restore(kept, None, dict(prefixes, OTHER=b"C:/x"), kd))
    row("a prefix the file does not hold refused", ok, why)
    ok, why = refused(lambda: kt.restore(kept, None, dict(prefixes, HOME83=prefixes["HOME"]), kd))
    row("the short form made from the long one refused", ok, why)
    ok, why = refused(lambda: kt.restore(kept, None, dict(prefixes, HOME_ESC=prefixes["HOME"]), kd))
    row("the escaped form made from the plain one refused", ok, why)

    # 7. a source that already holds a token's bytes
    s2 = os.path.join(base, "holds-a-token.txt")
    open(s2, "wb").write(data + kt.token("HOME"))
    ok, why = refused(lambda: kt.make([s2], prefixes, FORBID, os.path.join(base, "k7")))
    row("a source holding a token refused", ok, why)

    # 8. a spelling not given (another case) leaves the account's name: refused
    s3 = os.path.join(base, "other-case.txt")
    open(s3, "wb").write(data + b" c:/users/SomeOne/x")
    ok, why = refused(lambda: kt.make([s3], prefixes, FORBID, os.path.join(base, "k8")))
    row("a spelling not given (other case) refused", ok, why)

    # 9. the kept file damaged, or not the one the manifest names
    k9 = os.path.join(base, "k9")
    shutil.copytree(kd, k9)
    p9 = os.path.join(k9, kept[len("kept/"):])
    b9 = bytearray(open(p9, "rb").read())
    b9[len(b9) // 2] ^= 1
    open(p9, "wb").write(bytes(b9))
    ok, why = refused(lambda: kt.restore(kept, None, prefixes, k9))
    row("a damaged kept file refused", ok, why)

    # 10. nothing kept is written over
    ok, why = refused(lambda: kt.make([src], prefixes, FORBID, kd))
    row("keeping the same source again refused", ok, why)

    # 11. the real sources, if given
    if real:
        kr = os.path.join(base, "real")
        kt.make(real, real_prefixes, real_forbid, kr)
        for rel, length, digest, kept, kept_digest, counts in kt.rows(os.path.join(kr, "TOKENED.txt")):
            held = {k: v for k, v in real_prefixes.items() if counts.get(k)}
            back = kt.restore(kept, None, held, kr)
            with open(os.path.join(kt.ROOT, rel), "rb") as f:
                orig = f.read()
            row("real %s restored byte for byte" % rel, back == orig and kt.sha(back) == digest,
                ", ".join("%s=%d" % kv for kv in sorted(counts.items()) if kv[1]))
            for name in held:
                ok1, _ = refused(lambda: kt.restore(kept, None, {k: v for k, v in held.items() if k != name}, kr))
                ok2, _ = refused(lambda: kt.restore(kept, None, dict(held, **{name: held[name][:-1]}), kr))
                row("real %s: missing and wrong %s refused" % (os.path.basename(rel), name), ok1 and ok2)
    print("KEPT-TOKENS PLANTS: %d of %d as stated" % (sum(results), len(results)))
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
